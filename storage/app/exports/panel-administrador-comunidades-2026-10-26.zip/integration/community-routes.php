<?php

// Fragmento de routes/web.php: integrar, sin duplicar rutas existentes.
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Community\CommunityDashboardController;

Route::middleware('auth')->group(function (): void {
    Route::get('/wallet/tokens', [\App\Http\Controllers\Wallet\TokenWalletController::class, 'show'])->name('wallet.tokens');
    Route::middleware('role:superadmin,admin,patient')->prefix('communities/activities')->group(function (): void {
        Route::get('/', [\App\Http\Controllers\Community\CommunityActivityController::class, 'index']);
        Route::get('/{activity}/image', [\App\Http\Controllers\Community\CommunityActivityController::class, 'image'])->name('community.activities.image');
        Route::get('/{activity}/attendees', [\App\Http\Controllers\Community\CommunityActivityController::class, 'attendees'])->middleware('role:superadmin,admin');
        Route::post('/', [\App\Http\Controllers\Community\CommunityActivityController::class, 'store'])->middleware('role:superadmin,admin');
        Route::patch('/{activity}', [\App\Http\Controllers\Community\CommunityActivityController::class, 'publish'])->middleware('role:superadmin,admin');
        Route::post('/{activity}/reservation', [\App\Http\Controllers\Community\CommunityActivityController::class, 'reserve']);
        Route::delete('/{activity}/reservation', [\App\Http\Controllers\Community\CommunityActivityController::class, 'cancel']);
    });
    Route::get('/communities/admin', [CommunityDashboardController::class, 'admin'])
        ->middleware('role:superadmin,admin')->name('community.dashboard');
    Route::get('/communities', [CommunityDashboardController::class, 'explore'])
        ->middleware('role:superadmin,admin,patient')->name('community.explore');
});
